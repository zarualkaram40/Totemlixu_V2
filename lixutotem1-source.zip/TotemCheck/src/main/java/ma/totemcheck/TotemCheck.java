package ma.totemcheck;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.EntityEffect;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TotemCheck extends JavaPlugin implements Listener {

    private static final class Data {
        String name = "?";
        long lastPop = 0;
        int vl = 0;
        long lastDelta = -1;
        long sumDelta = 0;
        int samples = 0;
        int fastCount = 0;
    }

    /** Active /totempop test on a player. */
    private static final class PopTest {
        CommandSender admin;
        ItemStack savedOffhand;
        long start;
        BukkitTask timeout;
    }

    /** Holder so we can recognise our GUI safely. */
    private static final class GuiHolder implements InventoryHolder {
        private Inventory inv;
        @Override public @NotNull Inventory getInventory() { return inv; }
    }

    private final Map<UUID, Data> data = new ConcurrentHashMap<>();
    private final Map<UUID, PopTest> tests = new ConcurrentHashMap<>();
    private long thresholdMs;
    private int alertVl;
    private long maxWindowMs;
    private long testTimeoutMs;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        thresholdMs = getConfig().getLong("threshold-ms", 120);
        alertVl = getConfig().getInt("alert-vl", 1);
        maxWindowMs = getConfig().getLong("max-window-ms", 3000);
        testTimeoutMs = getConfig().getLong("test-timeout-ms", 3000);
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        // Rje3 l-items dyal ay test mazal khdam
        for (UUID id : List.copyOf(tests.keySet())) {
            PopTest t = tests.remove(id);
            Player p = Bukkit.getPlayer(id);
            if (t != null && p != null) restore(p, t.savedOffhand);
        }
    }

    private Data of(Player p) {
        Data d = data.computeIfAbsent(p.getUniqueId(), k -> new Data());
        d.name = p.getName();
        return d;
    }

    private static boolean isTotem(ItemStack i) {
        return i != null && i.getType() == Material.TOTEM_OF_UNDYING;
    }

    // ---- Detection -------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPop(EntityResurrectEvent e) {
        if (e.getEntity() instanceof Player p) {
            of(p).lastPop = System.nanoTime();
        }
    }

    /** F key / swap hands. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (isTotem(e.getOffHandItem())) {
            check(e.getPlayer());
        }
    }

    /** Inventory based re-equip. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory().getType() != InventoryType.PLAYER) return;

        boolean equipped = false;
        if (e.getClick() == ClickType.SWAP_OFFHAND && isTotem(e.getCurrentItem())) {
            equipped = true;
        } else if (e.getSlot() == 40 && isTotem(e.getCursor())) {
            equipped = true;
        } else if (e.getClick() == ClickType.NUMBER_KEY && e.getSlot() == 40
                && isTotem(p.getInventory().getItem(e.getHotbarButton()))) {
            equipped = true;
        }
        if (equipped) check(p);
    }

    private void check(Player p) {
        // Ila kayn /totempop test khdam => had l-equip houwa l-jawab
        PopTest test = tests.get(p.getUniqueId());
        if (test != null) {
            finishTest(p.getUniqueId(), (System.nanoTime() - test.start) / 1_000_000L);
            return;
        }

        Data d = of(p);
        if (d.lastPop == 0) return;
        long deltaMs = (System.nanoTime() - d.lastPop) / 1_000_000L;
        d.lastPop = 0;
        if (deltaMs > maxWindowMs) return;

        record(p, d, deltaMs);
    }

    /** Sjjel sample, zid VL ila sra3, w sift alert. */
    private void record(Player p, Data d, long deltaMs) {
        d.lastDelta = deltaMs;
        d.sumDelta += deltaMs;
        d.samples++;

        if (deltaMs < thresholdMs) {
            d.fastCount++;
            d.vl++;
            if (d.vl >= alertVl) alert(p, d, deltaMs);
        } else if (d.vl > 0 && d.samples % 3 == 0) {
            d.vl--;
        }
    }

    private void alert(Player p, Data d, long deltaMs) {
        Component msg = Component.text("[TotemCheck] ", NamedTextColor.RED, TextDecoration.BOLD)
                .append(Component.text(p.getName(), NamedTextColor.YELLOW))
                .append(Component.text(" kaystaaml AutoTotem (re-equip f " + deltaMs
                        + "ms, VL " + d.vl + ")", NamedTextColor.GRAY));
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("totemcheck.admin")) staff.sendMessage(msg);
        }
        getLogger().warning(p.getName() + " AutoTotem suspect: " + deltaMs + "ms VL=" + d.vl);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        Data d = data.get(p.getUniqueId());
        if (d != null) d.lastPop = 0;

        PopTest t = tests.remove(p.getUniqueId());
        if (t != null) {
            if (t.timeout != null) t.timeout.cancel();
            restore(p, t.savedOffhand);
            tell(t.admin, Component.text(p.getName() + " khrej f west l-test.", NamedTextColor.GRAY));
        }
    }

    // ---- /totempop -------------------------------------------------------

    private void startTest(CommandSender admin, Player target) {
        if (tests.containsKey(target.getUniqueId())) {
            tell(admin, Component.text("Test khdam deja 3la had l-player.", NamedTextColor.RED));
            return;
        }
        boolean hasTotem = false;
        for (ItemStack i : target.getInventory().getStorageContents()) {
            if (isTotem(i)) { hasTotem = true; break; }
        }
        if (!hasTotem) {
            tell(admin, Component.text(target.getName() + " ma 3andou 7ta totem f inventory (ghir f offhand mzyan), test ma ghaditch ykhdm.", NamedTextColor.RED));
            return;
        }

        PopTest t = new PopTest();
        t.admin = admin;
        PlayerInventory inv = target.getInventory();
        t.savedOffhand = inv.getItemInOffHand().clone();
        inv.setItemInOffHand(null);                      // offhand khawi bhal mli kaytfarqa3 totem
        target.playEffect(EntityEffect.PROTECTED_FROM_DEATH); // animation dyal totem
        t.start = System.nanoTime();
        tests.put(target.getUniqueId(), t);

        UUID id = target.getUniqueId();
        t.timeout = Bukkit.getScheduler().runTaskLater(this, () -> finishTest(id, -1),
                Math.max(1, testTimeoutMs / 50));

        tell(admin, Component.text("Totem t-popa 3la " + target.getName() + ", kan-tsenna " + testTimeoutMs + "ms...", NamedTextColor.GRAY));
    }

    /** deltaMs = -1 ya3ni ma-equipach. */
    private void finishTest(UUID id, long deltaMs) {
        PopTest t = tests.remove(id);
        if (t == null) return;
        if (t.timeout != null) t.timeout.cancel();

        Player p = Bukkit.getPlayer(id);
        if (p == null) return;

        // Rje3 l-item mn ba3d tick bach l-equip li dar daba y-kml
        Bukkit.getScheduler().runTask(this, () -> restore(p, t.savedOffhand));

        Component res;
        if (deltaMs < 0) {
            res = Component.text(p.getName() + " ma-equipach totem (" + testTimeoutMs + "ms douzo).", NamedTextColor.GREEN);
        } else {
            Data d = of(p);
            record(p, d, deltaMs);
            if (deltaMs < thresholdMs) {
                res = Component.text(p.getName() + " equipa totem f " + deltaMs + "ms => AUTO TOTEM!", NamedTextColor.RED, TextDecoration.BOLD);
            } else {
                res = Component.text(p.getName() + " equipa totem f " + deltaMs + "ms => ybane yedawi (manual).", NamedTextColor.YELLOW);
            }
        }
        tell(t.admin, Component.text("[TotemPop] ", NamedTextColor.GOLD).append(res));
    }

    private void restore(Player p, ItemStack saved) {
        if (saved == null || saved.getType().isAir()) return;
        PlayerInventory inv = p.getInventory();
        if (inv.getItemInOffHand().getType().isAir()) {
            inv.setItemInOffHand(saved);
        } else {
            inv.addItem(saved).values()
                    .forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
        }
    }

    private void tell(CommandSender s, Component c) {
        if (s != null) s.sendMessage(c);
    }

    // ---- Commands / GUI --------------------------------------------------

    @Override
    public boolean onCommand(@NotNull CommandSender s, @NotNull Command c, @NotNull String l, String @NotNull [] a) {
        if (!s.hasPermission("totemcheck.admin")) return true;

        if (c.getName().equalsIgnoreCase("totempop")) {
            if (a.length < 1) {
                s.sendMessage(Component.text("Usage: /totempop <player>", NamedTextColor.RED));
                return true;
            }
            Player t = Bukkit.getPlayerExact(a[0]);
            if (t == null) {
                s.sendMessage(Component.text("Player offline.", NamedTextColor.RED));
                return true;
            }
            startTest(s, t);
            return true;
        }

        if (a.length >= 1 && a[0].equalsIgnoreCase("resetall")) {
            data.clear();
            s.sendMessage(Component.text("Kolchi t-reseta.", NamedTextColor.GREEN));
            return true;
        }
        if (a.length >= 2 && a[0].equalsIgnoreCase("reset")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t != null) data.remove(t.getUniqueId());
            s.sendMessage(Component.text("Reset " + a[1], NamedTextColor.GREEN));
            return true;
        }
        if (s instanceof Player p) {
            openGui(p);
        } else {
            s.sendMessage("Hadchi GUI, khasso player.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender s, @NotNull Command c, @NotNull String l, String @NotNull [] a) {
        boolean pop = c.getName().equalsIgnoreCase("totempop");
        if (pop && a.length == 1) return players(a[0]);
        if (!pop && a.length == 1) {
            return List.of("reset", "resetall").stream()
                    .filter(x -> x.startsWith(a[0].toLowerCase())).toList();
        }
        if (!pop && a.length == 2 && a[0].equalsIgnoreCase("reset")) return players(a[1]);
        return List.of();
    }

    private List<String> players(String prefix) {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase().startsWith(prefix.toLowerCase())).toList();
    }

    private void openGui(Player viewer) {
        GuiHolder holder = new GuiHolder();
        Inventory inv = Bukkit.createInventory(holder, 54,
                Component.text("AutoTotem Suspects", NamedTextColor.DARK_RED));
        holder.inv = inv;

        List<Map.Entry<UUID, Data>> list = new ArrayList<>(data.entrySet());
        list.removeIf(en -> en.getValue().samples == 0);
        list.sort(Comparator.comparingInt((Map.Entry<UUID, Data> en) -> en.getValue().vl).reversed());

        int slot = 0;
        for (Map.Entry<UUID, Data> en : list) {
            if (slot >= 54) break;
            Data d = en.getValue();
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(en.getKey()));

            boolean suspect = d.vl >= alertVl;
            meta.displayName(Component.text(d.name, suspect ? NamedTextColor.RED : NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false));
            long avg = d.samples == 0 ? 0 : d.sumDelta / d.samples;
            meta.lore(List.of(
                    line("Status: ", suspect ? "AUTO TOTEM" : "Clean", suspect ? NamedTextColor.RED : NamedTextColor.GREEN),
                    line("VL: ", String.valueOf(d.vl), NamedTextColor.YELLOW),
                    line("Akhir delta: ", d.lastDelta + "ms", NamedTextColor.YELLOW),
                    line("Moyenna: ", avg + "ms", NamedTextColor.YELLOW),
                    line("Re-equips sra3: ", d.fastCount + "/" + d.samples, NamedTextColor.YELLOW)
            ));
            head.setItemMeta(meta);
            inv.setItem(slot++, head);
        }
        viewer.openInventory(inv);
    }

    private static Component line(String k, String v, NamedTextColor color) {
        return Component.text(k, NamedTextColor.GRAY).append(Component.text(v, color))
                .decoration(TextDecoration.ITALIC, false);
    }

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof GuiHolder) {
            e.setCancelled(true);
        }
    }
}
